<?php include 'header.html';?>


    <script src='../js/bootstrap.js'></script>
<?php

echo "What's in user info you ask?";
echo "<br></br>";
echo "It hasn't been implemented yet.";
?>