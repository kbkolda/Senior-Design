<!DOCTYPE HTML>
<html>
   <head>
      <!-- Page Title -->
      <title>Staff Menu :: ECC - Peace Lutheran Church</title>

      <!-- Common Tags -->
      <?php require('includes/head.php') ?> 
   </head>

   <body>
      <!-- Header -->
      <?php require('includes/header.php') ?>

      <!-- Content -->
      <div class="container-fluid" id="main_wrapper">
         <div class="row">
            <!-- Menu Column -->
            <div class="col-md-3 col-sm-12 col-12 no_space wow fadeInLeft" id="menu_wrapper">
               <!-- Title -->
               <div id="menu_name"> <i class="fas fa-user-tie menu_icons"></i> Staff </div>
               <!-- List -->
               <div id="menu_button_wrapper">
                  <div class="nav nav-tabs" id="nav-tab" role="tablist">
                     <!-- Tab 1 -->
                     <a class="active link menu_button_a" data-toggle="tab" href="#tab1" role="tab" aria-selected="true">
                     <button class="menu_button" id="first_menu_button">
                     Submitting a new staff calendar
                     </button></a>
                     <!-- Tab 2 -->
                     <a class="link menu_button_a" data-toggle="tab" href="#tab2" role="tab" aria-selected="true"> 
                     <button class="menu_button">
                     Adding a new staff member
                     </button></a>
                     <!-- Tab 3 -->
                     <a class="link menu_button_a" data-toggle="tab" href="#tab3" role="tab" aria-selected="true"> 
                     <button class="menu_button">
                     Changing a staff member information
                     </button></a> 
                     <!-- Tab 4 -->
                     <a class="link menu_button_a" data-toggle="tab" href="#tab4" role="tab" aria-selected="true"> 
                     <button class="menu_button">
                     Changing a password
                     </button></a>
                  </div>
               </div>
            </div>

            <!-- Space -->
            <div class="col-md-1 col-sm-12 col-12" id="space"></div>

            <!-- Main Content -->
            <div class="col-md-8 col-sm-12 col-12" id="secondery_wrapper">
               <div class="tab-content" id="nav-tabContent">
                  <!-- Tab 1 -->
                  <div class="tab-pane fade show active" id="tab1" role="tabpanel">
                     <!-- Step -->
                     <p class="instruction wow fadeIn">01. Click Staff on upper left corner right next to the Dates button.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/staff/calender1.png"> 
                       <img src="images/staff/calender1.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">02. Then choose the staff calendar option from the drop down menu and click it. It will open the following window.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/staff/calender2.png"> 
                       <img src="images/staff/calender2.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a> 
                     <!-- Step -->
                     <p class="instruction wow fadeIn">03. Click the downword arrow right above the submit button and choose your staff name from the drop down menu..</p>
                     <a class="fancybox link" rel="ligthbox" href="images/staff/calender3.png"> 
                       <img src="images/staff/calender3.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a> 
                     <!-- Step -->
                     <p class="instruction wow fadeIn">04. Choose a month from the calendar by clicking the right arrow above the Monday column.</p> 
                     <!-- Step -->
                     <p class="instruction wow fadeIn">05. Click a column and highlight all the dates you want to enter.</p> 
                     <!-- Step -->
                     <p class="instruction wow fadeIn">06. It will open the add event window. Enter the all relevent information.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/staff/calender4.png"> 
                       <img src="images/staff/calender4.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">07. Click save changes. It will display your information in the calendar.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/staff/calender5.png"> 
                       <img src="images/staff/calender5.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">08. Click submit button to submit your calendar.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/staff/calender6.png"> 
                       <img src="images/staff/calender6.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>      
                  </div> 
                  <!-- Tab 2 -->
                  <div class="tab-pane fade show" id="tab2" role="tabpanel"> 
                     <!-- Step -->
                     <p class="instruction wow fadeIn">01. Click Staff on upper left corner right next to the Dates button.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/staff/new_staff1.png"> 
                        <img src="images/staff/new_staff1.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">02. Then choose the Add Staff from the drop down menu and click it. It will open the following window.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/staff/new_staff2.png"> 
                        <img src="images/staff/new_staff2.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">03. Fill all the information and then click the submit button.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/staff/new_staff3.png"> 
                        <img src="images/staff/new_staff3.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a> 
                  </div>
                  <!-- Tab 3 -->
                  <div class="tab-pane fade show" id="tab3" role="tabpanel"> 
                  	Content Coming Soon !
                  </div>
                  <!-- Tab 4 -->
                  <div class="tab-pane fade show" id="tab4" role="tabpanel"> 
                  	<!-- Step -->
                     <p class="instruction wow fadeIn">01. Click Staff on upper left corner right next to the Dates button.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/staff/password1.png"> 
                        <img src="images/staff/password1.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">02. Then choose the Change Password from the drop down menu and click it. It will open the following window.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/staff/password2.png"> 
                        <img src="images/staff/password2.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">03. Click the downward arrow and then select the name from the drop down menu.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/staff/password3.png"> 
                        <img src="images/staff/password3.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">04. Then type the new password in password field and click the submit button</p>
                     <a class="fancybox link" rel="ligthbox" href="images/staff/password4.png"> 
                        <img src="images/staff/password4.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                  </div> 
               </div>
            </div>
         </div>
      </div>

      <!-- Footer -->
      <?php require('includes/footer.php') ?> 

   </body>
</html>