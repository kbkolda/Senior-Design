     <!-- Highlight Current Tab On Click --> 
      <script type="text/javascript">
         $('.menu_button').click(function(){
           $('.menu_button.menu_highlight').removeClass('menu_highlight')
               $(this).addClass('menu_highlight');
         });
      </script> 

      <!-- Scroll to Content Section On Click (Mobile Version Only) -->  
      <script>
      $(window).load(function(){        
      if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.      test(navigator.userAgent) ) {
      } else {
         $(".menu_button_a").click(function() {
            $('html, body').animate({
                scrollTop: $("#secondery_wrapper").offset().top
            }, 0);
         });
      });  
      </script>  

      <!-- Automatically Click 1st Menu Button on Page Load -->
      <script>
         jQuery(function(){
            jQuery('#first_menu_button').click();
         });
      </script> 

