<div class="container-fluid" id="header">
   <div class="row">
   	<!-- Logo -->
      <div class="col-sm-12 col-md-4 col-12">
         <a href="index.php">
         <img src="images/header/logo.png" class="img-fluid" id="logo"/>
         </a>
      </div>
      <!-- Title -->
      <div class="col-sm-12 col-md-7 col-12">
         <p id="project_name"> ECC Dashboard - Online Guide </p>
      </div>
      <!-- Go Back Icon -->
      <div class="col-sm-12 col-md-1 col-12">
         <a href="index.php" id="home_link" class="link" data-toggle="tooltip" title="Back to Main Page">
         <i class="fas fa-home"></i></a>
      </div>
   </div>
</div>