<!DOCTYPE HTML>
<html>
   <head>
      <!-- Page Title -->
      <title>Home Page :: ECC - Peace Lutheran Church</title>

      <!-- Common Tags -->
      <?php require('includes/head.php') ?> 
   </head>

   <body>
      <!-- Header -->
      <?php require('includes/header.php') ?>

      <!-- Content -->
      <div class="container-fluid" id="main_wrapper">
         <div class="row">
            <!-- Menu Column -->
            <div class="col-md-3 col-sm-12 col-12 no_space wow fadeInLeft" id="menu_wrapper">
               <!-- Title -->
               <div id="menu_name"> <i class="fa fa-home menu_icons"></i> Home Page View </div>
               <!-- List -->
               <div id="menu_button_wrapper">
                  <div class="nav nav-tabs" id="nav-tab" role="tablist">
                     <!-- Tab 1 -->
                     <a class="active link menu_button_a" data-toggle="tab" href="#tab1" role="tab" aria-selected="true">
                     <button class="menu_button" id="first_menu_button">
                     Menu for admin functionalities
                     </button></a>
                     <!-- Tab 2 -->
                     <a class="link menu_button_a" data-toggle="tab" href="#tab2" role="tab" aria-selected="true"> 
                     <button class="menu_button">
                     Help menu
                     </button></a>
                     <!-- Tab 3 -->
                     <a class="link menu_button_a" data-toggle="tab" href="#tab3" role="tab" aria-selected="true"> 
                     <button class="menu_button">
                     View Past and Future Calendar
                     </button></a> 
                     <!-- Tab 4 -->
                     <a class="link menu_button_a" data-toggle="tab" href="#tab4" role="tab" aria-selected="true"> 
                     <button class="menu_button">
                     Change the Calender View
                     </button></a>
                     <!-- Tab 5 -->
                     <a class="link menu_button_a" data-toggle="tab" href="#tab5" role="tab" aria-selected="true"> 
                     <button class="menu_button">
                     Calendar
                     </button></a>
                  </div>
               </div>
            </div>

            <!-- Space -->
            <div class="col-md-1 col-sm-12 col-12" id="space"></div>

            <!-- Main Content -->
            <div class="col-md-8 col-sm-12 col-12" id="secondery_wrapper">
               <div class="tab-content" id="nav-tabContent">
                  <!-- Tab 1 -->
                  <div class="tab-pane fade show active" id="tab1" role="tabpanel"> 
                  	 <!-- Details -->
                     <a class="fancybox link" rel="ligthbox" href="images/home/View.png"> 
                       <img src="images/home/View.png" class="home_screenshot wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <table class="table custom_table">
                     	<tbody>
                     		<tr>
                     			<td>Home</td>
                     			<td>:</td>
                     			<td>Home button will redirect you back to the home page</td>
                     		</tr>
                     		<tr>
                     			<td>User</td>
                     			<td>:</td>
                     			<td>Click User for more information</td>
                     		</tr>
                     		<tr>
                     			<td>Admin</td>
                     			<td>:</td>
                     			<td>Click User for more information</td>
                     		</tr>
                     		<tr>
                     			<td>Dates</td>
                     			<td>:</td>
                     			<td>Click User for more information</td>
                     		</tr>
                     		<tr>
                     			<td>Staff</td>
                     			<td>:</td>
                     			<td>Click User for more information</td>
                     		</tr>
                     	</tbody>
                     </table> 
                  </div> 
                  <!-- Tab 2 -->
                  <div class="tab-pane fade show" id="tab2" role="tabpanel"> 
                     <!-- Details -->
                     <a class="fancybox link" rel="ligthbox" href="images/home/View.png"> 
                       <img src="images/home/View.png" class="home_screenshot wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <table class="table custom_table">
                     	<tbody>
                     		<tr>
                     			<td>Change Log</td>
                     			<td>:</td>
                     			<td>Change Log will contain all the previous versions changes and released dates. This was intened for the future developers.</td>
                     		</tr>
                     		<tr>
                     			<td>Help</td>
                     			<td>:</td>
                     			<td>Help will display all the informations about how to operate the web system</td>
                     		</tr>
                     		<tr>
                     			<td>Log Out</td>
                     			<td>:</td>
                     			<td>Log you out from the system. Admin function has the power to change data in the system. For the <span class="font_weight">safety reasons</span> it is recommended to log out from the system before you leave your device.</td>
                     		</tr> 
                     	</tbody>
                     </table>
                  </div> 
                  <!-- Tab 3 -->
                  <div class="tab-pane fade show" id="tab3" role="tabpanel"> 
                  	<!-- Details -->
                     <a class="fancybox link" rel="ligthbox" href="images/home/View.png"> 
                       <img src="images/home/View.png" class="home_screenshot wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <table class="table custom_table">
                     	<tbody>
                     		<tr>
                     			<td>Left Arrow</td>
                     			<td>:</td>
                     			<td>By clicking the left arrow you can view the past calendars.</td>
                     		</tr>
                     		<tr>
                     			<td>Right Arrow</td>
                     			<td>:</td>
                     			<td>By clicking the right arrow you can view the calendars for upcoming months.</td>
                     		</tr>
                     		<tr>
                     			<td>Today</td>
                     			<td>:</td>
                     			<td>Clicking this will redirect you to the current date.</td>
                     		</tr> 
                     	</tbody>
                     </table>
                  </div> 
                  <!-- Tab 4 -->
                  <div class="tab-pane fade show" id="tab4" role="tabpanel"> 
                  	<!-- Details -->
                     <a class="fancybox link" rel="ligthbox" href="images/home/View.png"> 
                       <img src="images/home/View.png" class="home_screenshot wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <table class="table custom_table">
                     	<tbody>
                     		<tr>
                     			<td>Month</td>
                     			<td>:</td>
                     			<td>This is the default option for the calendar. Display the current month with all the records</td>
                     		</tr>
                     		<tr>
                     			<td>List day</td>
                     			<td>:</td>
                     			<td>This will display the all the records of current date. A great option to inspect all the records of a specific day. By clicking the left and right arrow in upper left corner you can inspect the records of past and future dates. If you click the today option when you are inspecting the past or future record it will automativcally bring you to the current date.</td>
                     		</tr>
                     		<tr>
                     			<td>List week</td>
                     			<td>:</td>
                     			<td>This will display the all the records of current week. A great option to inspect all the records of a specific week. By clicking the left and right arrow in upper left corner you can inspect the records of past and future weeks. If you click the today option when you are inspecting the past or future record it will automativcally bring you to the current week.</td>
                     		</tr> 
                     	</tbody>
                     </table>
                 </div>
                 <!-- Tab 5 -->
                  <div class="tab-pane fade show" id="tab5" role="tabpanel"> 
                  	<!-- Details -->
                     <a class="fancybox link" rel="ligthbox" href="images/home/View.png"> 
                       <img src="images/home/View.png" class="home_screenshot wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <table class="table custom_table">
                     	<tbody>
                     		<tr> 
                     			<td colspan="3">This is the default view of your calendar. You can change the view using the 3 buttons above the Friday columns. Please refer to <span class="font_weight">4</span> for more options. The Grey cells represent the past dates and light cells display the present and future dates.<br>
                                <br>
                     			<span class="font_weight">Important :</span> If a background color of a cell is Grey you can't modify the data.</td>
                     		</tr>
                     		 
                     	</tbody>
                     </table>
                 </div>
            </div>
         </div>
      </div>

      <!-- Footer -->
      <?php require('includes/footer.php') ?> 

   </body>
</html>