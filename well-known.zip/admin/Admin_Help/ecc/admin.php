<!DOCTYPE HTML>
<html>
   <head>
      <!-- Page Title -->
      <title>Admin Menu :: ECC - Peace Lutheran Church</title>

      <!-- Common Tags -->
      <?php require('includes/head.php') ?> 
   </head>

   <body>
      <!-- Header -->
      <?php require('includes/header.php') ?>

      <!-- Content -->
      <div class="container-fluid" id="main_wrapper">
         <div class="row">
            <!-- Menu Column -->
            <div class="col-md-3 col-sm-12 col-12 no_space wow fadeInLeft" id="menu_wrapper">
               <!-- Title -->
               <div id="menu_name"> <i class="fas fa-star menu_icons"></i> Admin </div>
               <!-- List -->
               <div id="menu_button_wrapper">
                  <div class="nav nav-tabs" id="nav-tab" role="tablist">
                     <!-- Tab 1 -->
                     <a class="active link menu_button_a" data-toggle="tab" href="#tab1" role="tab" aria-selected="true">
                     <button class="menu_button" id="first_menu_button">
                     Changing a Password
                     </button></a>
                     <!-- Tab 2 -->
                     <a class="link menu_button_a" data-toggle="tab" href="#tab2" role="tab" aria-selected="true"> 
                     <button class="menu_button">
                     Changing a notification email address
                     </button></a>
                     <!-- Tab 3 -->
                     <a class="link menu_button_a" data-toggle="tab" href="#tab3" role="tab" aria-selected="true"> 
                     <button class="menu_button">
                     Changing a ECC email address
                     </button></a>
                     <!-- Tab 4 -->
                     <a class="link menu_button_a" data-toggle="tab" href="#tab4" role="tab" aria-selected="true"> 
                     <button class="menu_button">
                     Archiving
                     </button></a>
                     <!-- Tab 5 -->
                     <a class="link menu_button_a" data-toggle="tab" href="#tab5" role="tab" aria-selected="true"> 
                     <button class="menu_button">
                     Clear Archives
                     </button></a>
                     <!-- Tab 6 -->
                     <a class="link menu_button_a" data-toggle="tab" href="#tab6" role="tab" aria-selected="true"> 
                     <button class="menu_button">
                     Generate a Child Daily Sheet
                     </button></a>
                     <!-- Tab 7 -->
                     <a class="link menu_button_a" data-toggle="tab" href="#tab7" role="tab" aria-selected="true"> 
                     <button class="menu_button">
                     Generate a Staff Daily Sheet
                     </button></a>
                     <!-- Tab 8 -->
                     <a class="link menu_button_a" data-toggle="tab" href="#tab8" role="tab" aria-selected="true"> 
                     <button class="menu_button">
                     Add/Remove a Class Room
                     </button></a>
                     <!-- Tab 9 -->
                     <a class="link menu_button_a" data-toggle="tab" href="#tab9" role="tab" aria-selected="true"> 
                     <button class="menu_button">
                     Export a User List
                     </button></a>
                     <!-- Tab 10 -->
                     <a class="link menu_button_a" data-toggle="tab" href="#tab10" role="tab" aria-selected="true"> 
                     <button class="menu_button">
                     Export a Staff List
                     </button></a>
                     <!-- Tab 11 -->
                     <a class="link menu_button_a" data-toggle="tab" href="#tab11" role="tab" aria-selected="true"> 
                     <button class="menu_button">
                     Export a Unsubmitted User List
                     </button></a>
                     <!-- Tab 12 -->
                     <a class="link menu_button_a" data-toggle="tab" href="#tab12" role="tab" aria-selected="true"> 
                     <button class="menu_button">
                     Email Notification 
                     </button></a>
                     <!-- Tab 13 -->
                     <a class="link menu_button_a" data-toggle="tab" href="#tab13" role="tab" aria-selected="true"> 
                     <button class="menu_button">
                     Sidebar Notification
                     </button></a>
                  </div>
               </div>
            </div>

            <!-- Space -->
            <div class="col-md-1 col-sm-12 col-12" id="space"></div>

            <!-- Main Content -->
            <div class="col-md-8 col-sm-12 col-12" id="secondery_wrapper">
               <div class="tab-content" id="nav-tabContent">
                  <!-- Tab 1 -->
                  <div class="tab-pane fade show active" id="tab1" role="tabpanel">
                     <!-- Step -->
                     <p class="instruction wow fadeIn">01. Click Admin on upper left corner right next to the User button.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/password1.png"> 
                       <img src="images/admin/password1.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">02. Then choose the Change Password from the drop down menu and click it. It will open the following window.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/password2.png"> 
                       <img src="images/admin/password2.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">03. Enter the new password and then click submit button.</p> 
                     <!-- Step -->
                     <p class="instruction wow fadeIn">04. Congratulation! You have successfully changed admin password.</p> 
                  </div> 
                  <!-- Tab 2 -->
                  <div class="tab-pane fade show" id="tab2" role="tabpanel">
                     <!-- Step -->
                     <p class="instruction wow fadeIn">01. Click Admin on upper left corner right next to the User button.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/email1.png"> 
                       <img src="images/admin/email1.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">02. Then choose the Change Distro Email from the drop down menu and click it. It will open the following window.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/email2.png"> 
                       <img src="images/admin/email2.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">03. Under the current email system, you can see the email address used tosend notifications.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/email3.png"> 
                       <img src="images/admin/email3.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">04. If you want to change that enter the new email address and password and then click submit button.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/email4.png"> 
                       <img src="images/admin/email4.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                  </div>
                  <!-- Tab 3 -->
                  <div class="tab-pane fade show" id="tab3" role="tabpanel">
                     <!-- Step -->
                     <p class="instruction wow fadeIn">01. Click Admin on upper left corner right next to the User button.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/email5.png"> 
                       <img src="images/admin/email5.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">02. Then choose the Change Historical Email from the drop down menu and click it. It will open the following window.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/email6.png"> 
                       <img src="images/admin/email6.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">03. Under the current email system, you can see the email address used by ECC.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/email3.png"> 
                       <img src="images/admin/email3.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">04. If you want to change that enter the new email address and then click submit button.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/email4.png"> 
                       <img src="images/admin/email4.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>  
                  </div> 
                  <!-- Tab 4 -->
                  <div class="tab-pane fade show" id="tab4" role="tabpanel">
                     <!-- Step -->
                     <p class="instruction wow fadeIn">01. Click Admin on upper left corner right next to the User button.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/archive4.png"> 
                       <img src="images/admin/archive4.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">02. Then choose the Archives from the drop down menu and click it. It will open the download process.</p> 
                     <!-- Step -->
                     <p class="instruction wow fadeIn">03. The downloaded file will be appear as under the name of Archive.xls</p>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">04. In windows download folder is located in C:\Downloads.</p>  
                     <a class="fancybox link" rel="ligthbox" href="images/admin/archive5.png"> 
                       <img src="images/admin/archive5.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">04. In Mac O/S download folder is located in Go -> Downloads.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/archive6.jpg"> 
                       <img src="images/admin/archive6.jpg" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                  </div>
                  <!-- Tab 5 -->
                  <div class="tab-pane fade show" id="tab5" role="tabpanel">
                     <!-- Step -->
                     <p class="instruction wow fadeIn">01. Click Admin on upper left corner right next to the User button.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/archive1.png"> 
                       <img src="images/admin/archive1.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">02. Then choose the Clear Archives from the drop down menu and click it. It will open the following window.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/archive2.png"> 
                       <img src="images/admin/archive2.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">03. Click the calendar icon right above the Clear button and select a day.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/archive3.png"> 
                       <img src="images/admin/archive3.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">04. After selecting a day click the clear button to clear the archives of that day.</p>  
                  </div>
                  <!-- Tab 6 -->
                  <div class="tab-pane fade show" id="tab6" role="tabpanel">
                     <!-- Step -->
                     <p class="instruction wow fadeIn">01. Click Admin on upper left corner right next to the User button.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/child1.png"> 
                       <img src="images/admin/child1.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">02. Then choose the Child Daily Sheet from the drop down menu and click it. It will open the following window.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/child2.png"> 
                       <img src="images/admin/child2.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">03. Click the calendar icon right above the Generate button and select a date.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/child3.png"> 
                       <img src="images/admin/child3.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">04. Then click the Generate button.</p>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">05. The downloaded file will be appear as under the name of DailySheet.xls</p>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">06. In windows download folder is located in C:\Downloads.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/child4.png"> 
                       <img src="images/admin/child4.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">07. In Mac O/S download folder is located in Go -> Downloads.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/child5.jpg"> 
                       <img src="images/admin/child5.jpg" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>  
                  </div>
                  <!-- Tab 7 -->
                  <div class="tab-pane fade show" id="tab7" role="tabpanel">
                     <!-- Step -->
                     <p class="instruction wow fadeIn">01. Click Admin on upper left corner right next to the User button.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/staff1.png"> 
                       <img src="images/admin/staff1.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">02. Then choose the Staff Daily Sheet from the drop down menu and click it. It will open the following window.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/child2.png"> 
                       <img src="images/admin/child2.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">03. Click the calendar icon right above the Generate button and select a date.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/child3.png"> 
                       <img src="images/admin/child3.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">04. Then click the Generate button.</p>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">05. The downloaded file will be appear as under the name of DailySheet.xls</p>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">06. In windows download folder is located in C:\Downloads.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/child4.png"> 
                       <img src="images/admin/child4.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">07. In Mac O/S download folder is located in Go -> Downloads.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/child5.jpg"> 
                       <img src="images/admin/child5.jpg" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>  
                  </div> 
                  <!-- Tab 8 -->
                  <div class="tab-pane fade show" id="tab8" role="tabpanel">
                     <!-- Step -->
                     <p class="instruction wow fadeIn">01. Click Admin on upper left corner right next to the User button.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/room1.png"> 
                       <img src="images/admin/room1.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">02. Then choose the ADD/Remove Class Room from the drop down menu and click it. It will open the following window.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/room2.png"> 
                       <img src="images/admin/room2.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step Title -->
                     <p class="step_title wow fadeIn">To Remove a Class</p> 
                     <!-- Step -->
                     <p class="instruction wow fadeIn">03. Click the downward arrow right above the Remove button and select a class from a drop down menu.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/room3.png"> 
                       <img src="images/admin/room3.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a> 
                     <!-- Step -->
                     <p class="instruction wow fadeIn">04. Then click the Remove button.</p>
                     <!-- Step Title -->
                     <p class="step_title wow fadeIn">To Add a Class</p>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">05. Type the name in New Class text field and then Click the Add button.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/room4.png"> 
                       <img src="images/admin/room4.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a> 
                  </div>
                  <!-- Tab 9 -->
                  <div class="tab-pane fade show" id="tab9" role="tabpanel">
                     <!-- Step -->
                     <p class="instruction wow fadeIn">01. Click Admin on upper left corner right next to the User button.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/userlist1.png"> 
                       <img src="images/admin/userlist1.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">02. Then choose the Export User List from the drop down menu and click it. It will open the download process.</p> 
                     <!-- Step -->
                     <p class="instruction wow fadeIn">03. The downloaded file will be appear as under the name of UserDistro.xls</p> 
                     <!-- Step -->
                     <p class="instruction wow fadeIn">04. In windows download folder is located in C:\Downloads.</p> 
                     <a class="fancybox link" rel="ligthbox" href="images/admin/userlist2.png"> 
                       <img src="images/admin/userlist2.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">05. In Mac O/S download folder is located in Go -> Downloads.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/userlist3.jpg"> 
                       <img src="images/admin/userlist3.jpg" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>  
                  </div>
                  <!-- Tab 10 -->
                  <div class="tab-pane fade show" id="tab10" role="tabpanel">
                     <!-- Step -->
                     <p class="instruction wow fadeIn">01. Click Admin on upper left corner right next to the User button.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/staff2.png"> 
                       <img src="images/admin/staff2.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">02. Then choose the Export Staff List from the drop down menu and click it. It will open the download process.</p> 
                     <!-- Step -->
                     <p class="instruction wow fadeIn">03. The downloaded file will be appear as under the name of StaffDistro.xls</p> 
                     <!-- Step -->
                     <p class="instruction wow fadeIn">04. In windows download folder is located in C:\Downloads.</p> 
                     <a class="fancybox link" rel="ligthbox" href="images/admin/userlist2.png"> 
                       <img src="images/admin/userlist2.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">05. In Mac O/S download folder is located in Go -> Downloads.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/userlist3.jpg"> 
                       <img src="images/admin/userlist3.jpg" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>  
                  </div>
                  <!-- Tab 11 -->
                  <div class="tab-pane fade show" id="tab11" role="tabpanel">
                     <!-- Step -->
                     <p class="instruction wow fadeIn">01. Click Admin on upper left corner right next to the User button.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/unsubmit1.png"> 
                       <img src="images/admin/unsubmit1.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">02. Then choose the Export unsubmitted Users from the drop down menu and click it. It will open the download process.</p> 
                     <!-- Step -->
                     <p class="instruction wow fadeIn">03. The downloaded file will be appear as under the name of UnsubmittedUsers.xls</p> 
                     <!-- Step -->
                     <p class="instruction wow fadeIn">04. In windows download folder is located in C:\Downloads.</p> 
                     <a class="fancybox link" rel="ligthbox" href="images/admin/userlist2.png"> 
                       <img src="images/admin/userlist2.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">05. In Mac O/S download folder is located in Go -> Downloads.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/admin/userlist3.jpg"> 
                       <img src="images/admin/userlist3.jpg" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>  
                  </div>
                  <!-- Tab 12 -->
                  <div class="tab-pane fade show" id="tab12" role="tabpanel"> Content Coming Soon ! </div>
                  <!-- Tab 13 -->
                  <div class="tab-pane fade show" id="tab13" role="tabpanel"> Content Coming Soon !! </div>  
               </div>
            </div>
         </div>
      </div>

      <!-- Footer -->
      <?php require('includes/footer.php') ?> 

   </body>
</html>