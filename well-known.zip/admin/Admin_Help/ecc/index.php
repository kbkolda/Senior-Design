<!DOCTYPE HTML>
<html>
   <head>
      <!-- Page Title -->
      <title>ECC Admin User Manual :: Peace Lutheran Church</title>

      <!-- Common Tags -->
      <?php require('includes/head.php') ?> 
   </head>

   <body>
      <!-- Header -->
      <?php require('includes/header.php') ?>

      <!-- Introduction -->
      <div class="container-fluid">
         <div class="row">
            <div class="col-md-12 col-sm-12 col-12">
               <!-- Title -->
               <p id="home_title">How Can We Help?</p>
               <!-- Text -->
               <p id="home_introduction">We want you to have the simplest easiest user experiecne possible.
               <br class="desktop_br"> 
               But we know you might have few questions.
               <br class="desktop_br"> 
               Read on for details about functionalities of the admins.</p>
            </div>
         </div>
      </div>

      <!-- Menu -->
      <div class="container-fluid" id="home_page_buttons_wrapper">
         <div class="row">
         	<!-- Space -->
            <div class="col-md-1 col-sm-12 col-12"></div>
            <!-- Home Page -->
            <div class="col-md-2 col-sm-12 col-12">
               <a href="home.php" class="shading link">
               <button class="home_button"><i class="fa fa-home home_menu_icons"></i> Home Page</button> </a>
            </div>
            <!-- User Menu -->
            <div class="col-md-2 col-sm-12 col-12">
               <a href="user_menu.php" class="shading link">
               <button class="home_button"><i class="fas fa-user home_menu_icons"></i> User Menu</button> </a>
            </div>
            <!-- Admin -->
            <div class="col-md-2 col-sm-12 col-12"> <a href="admin.php" class="shading link">
               <button class="home_button"><i class="fas fa-star home_menu_icons"></i> Admin</button></a>
            </div>
            <!-- Dates -->
            <div class="col-md-2 col-sm-12 col-12"> <a href="dates.php" class="shading link">
               <button class="home_button"><i class="fas fa-calendar home_menu_icons"></i> Dates</button></a>
            </div>
            <!-- Staff -->
            <div class="col-md-2 col-sm-12 col-12"> <a href="staff.php" class="shading link">
               <button class="home_button"><i class="fas fa-user-tie home_menu_icons"></i> Staff</button></a>
            </div>
            <!-- Space -->
            <div class="col-md-1 col-sm-12 col-12"></div>
         </div>
      </div>

   </body>
</html>