<!DOCTYPE HTML>
<html>
   <head>
      <!-- Page Title -->
      <title>Dates Menu :: ECC - Peace Lutheran Church</title>

      <!-- Common Tags -->
      <?php require('includes/head.php') ?> 
   </head>

   <body>
      <!-- Header -->
      <?php require('includes/header.php') ?>

      <!-- Content -->
      <div class="container-fluid" id="main_wrapper">
         <div class="row">
            <!-- Menu Column -->
            <div class="col-md-3 col-sm-12 col-12 no_space wow fadeInLeft" id="menu_wrapper">
               <!-- Title -->
               <div id="menu_name"> <i class="fas fa-calendar menu_icons"></i> Dates </div>
               <!-- List -->
               <div id="menu_button_wrapper">
                  <div class="nav nav-tabs" id="nav-tab" role="tablist">
                     <!-- Tab 1 -->
                     <a class="active link menu_button_a" data-toggle="tab" href="#tab1" role="tab" aria-selected="true">
                     <button class="menu_button" id="first_menu_button">
                     Blocking and Unblocking Dates
                     </button></a>
                     <!-- Tab 2 -->
                     <a class="link menu_button_a" data-toggle="tab" href="#tab2" role="tab" aria-selected="true"> 
                     <button class="menu_button">
                     Removing an Event
                     </button></a> 
                  </div>
               </div>
            </div>

            <!-- Space -->
            <div class="col-md-1 col-sm-12 col-12" id="space"></div>

            <!-- Main Content -->
            <div class="col-md-8 col-sm-12 col-12" id="secondery_wrapper">
               <div class="tab-content" id="nav-tabContent">
                  <!-- Tab 1 -->
                  <div class="tab-pane fade show active" id="tab1" role="tabpanel">
                     <!-- Step -->
                     <p class="instruction wow fadeIn">01. Click Dates on upper left corner right next to the Admin button.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/dates/block_date1.png"> 
                       <img src="images/dates/block_date1.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">02. Then choose the add child from the drop down menu and click it. It will open the following window.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/dates/block_date2.png"> 
                       <img src="images/dates/block_date2.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">03. To block a date click the calendar icon above to the Add button and choose a date from the calendar.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/dates/block_date3.png"> 
                       <img src="images/dates/block_date3.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a> 
                     <!-- Step -->
                     <p class="instruction wow fadeIn">04. Click the Add button to block the date.</p>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">05. If successfull the date will appear under the block dates section.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/dates/block_date4.png"> 
                       <img src="images/dates/block_date4.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a> 
                     <!-- Step Title -->
                     <p class="step_title wow fadeIn">Unblocking a Date</p>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">01. To unblock a date click the dowanward arrow icon above to the remove button and choose a date from the menu.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/dates/block_date5.png"> 
                       <img src="images/dates/block_date5.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">02. Click the Remove button to unblock the date.</p> 
                     <!-- Step -->
                     <p class="instruction wow fadeIn">03. If successfull the date will disappear under the block dates section.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/dates/block_date6.png"> 
                       <img src="images/dates/block_date6.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>  
                  </div> 
                  <!-- Tab 2 -->
                  <div class="tab-pane fade show" id="tab2" role="tabpanel">
                     <!-- Step -->
                     <p class="instruction wow fadeIn">01. Click Dates on upper left corner right next to the Home button.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/dates/remove_event1.png"> 
                        <img src="images/dates/remove_event1.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">02. Then click the calendar icon above the remove button and choose a date.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/dates/remove_event2.png"> 
                       <img src="images/dates/remove_event2.png" class=" wow fadeIn img-fluid instruction_image"/>
                    </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">03. Then click the Remove button to remove an event.</p>
                     <a class="fancybox link" rel="ligthbox" href="images/dates/remove_event3.png"> 
                       <img src="images/dates/remove_event3.png" class=" wow fadeIn img-fluid instruction_image"/>
                     </a>
                     <!-- Step -->
                     <p class="instruction wow fadeIn">04. Congratulation! You have successfully removed an event from the system.</p>
                  </div> 
               </div>
            </div>
         </div>
      </div>

      <!-- Footer -->
      <?php require('includes/footer.php') ?> 

   </body>
</html>