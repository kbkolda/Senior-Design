<?php

header("Location: user/login/login");

?>