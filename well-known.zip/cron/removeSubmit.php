<?php
require_once('bdd.php');


$sql = "UPDATE userinfo set submitState = '0'";
$query = $bdd->prepare( $sql );

$sth = $query->execute();

$sql = "UPDATE staff set submitState = '0'";
$query = $bdd->prepare( $sql );

$sth = $query->execute();




?>