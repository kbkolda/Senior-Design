<?php



$today = date("H:i:s");  
echo $today;
//echo "." . PATH_SEPARATOR . ($UserDir = dirname($_SERVER['DOCUMENT_ROOT'])) . "/php" . PATH_SEPARATOR . get_include_path();

//echo "/home4/peacebr2/php/";

?>