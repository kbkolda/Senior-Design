<?php

function sendEmail1($month)
{
    require_once('bdd.php');

    set_include_path("/home4/peacebr2/php");
    require_once "Mail.php";
    
    $servername = "localhost";
    $username = "peacebr2_user";
    $password = "dbuser";
    $dbname = "peacebr2_db";
    $conn = new mysqli($servername, $username, $password, $dbname);

    $sql = "SELECT ".$month." FROM calendar WHERE notification='first'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc(); 
    $first = $row[$month];
    $first = date("m-d-Y", strtotime($first));
    
    $sql = "SELECT ".$month." FROM calendar WHERE notification='last'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc(); 
    $last = $row[$month];
    $last = date("m-d-Y", strtotime($last));
    
    $sql = "SELECT ".$month." FROM calendar WHERE notification='due'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc(); 
    $due = $row[$month];
    $due = date("m-d-Y", strtotime($due));

    $sql = "SELECT email FROM email";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $email = $row["email"];

    //WHO THE EMAIL IS DELIVERED TO
    //$usersql = "SELECT email from testemail";
    $usersql = "SELECT userinfo.email FROM userinfo INNER JOIN user ON userinfo.userID=user.userID WHERE user.archive = 0";
    
        $query = $bdd->prepare( $usersql );
        $useremail = "";
        foreach($bdd->query($usersql) as $row)
        {
            $useremail = $row['email'];
            $servermail = "";
            $serverpass = "";
            $serversql = "select email,password from distro";
            $serveryQuery = $bdd->prepare($serversql);
            foreach($bdd->query($serversql) as $row)
            {
                $servermail = $row['email'];
                $serverpass = $row['password'];
            }
            
            $to     =   $useremail;
            $from   =   $servermail;
            $time = strtotime(date("Y-m-d"));
            $final = date("Y-m", strtotime("+1 month", $time));
            $forDate = date("F j, Y",strtotime($final));
            $subject = "Peace Brookings: Reminder to update calendar!";
            //$body = "";
            $body = "Please click the link below to update calendar for $first thru $last. \n";
            $body .="This calendar is due on $due \n\n";
            $body .= "https://www.peacebrookingscalendar.org/ \n\n";
            $body .="$email";
            $host    = "peacebrookingscalendar.org";
            $port    =  "587";
            $user    = $servermail;
            $pass    = $serverpass;
            $headers = array("From"=> $from, "To"=>$to, "Subject"=>$subject);
            $smtp    = @Mail::factory("smtp", array("host"=>$host, "port"=>$port, "auth"=> true, "username"=>$user, "password"=>$pass));
            $mail    = @$smtp->send($to, $headers, $body);
    
            
        }
        
        //$usersql = "SELECT email from testemail";
        $usersql = "SELECT email FROM staff WHERE archive = 0";
    
        $query = $bdd->prepare( $usersql );
        $useremail = "";
        foreach($bdd->query($usersql) as $row)
        {
            $useremail = $row['email'];
            $servermail = "";
            $serverpass = "";
            $serversql = "select email,password from distro";
            $serveryQuery = $bdd->prepare($serversql);
            foreach($bdd->query($serversql) as $row)
            {
                $servermail = $row['email'];
                $serverpass = $row['password'];
            }
            
            $to     =   $useremail;
            $from   =   $servermail;
            $time = strtotime(date("Y-m-d"));
            $final = date("Y-m", strtotime("+1 month", $time));
            $forDate = date("F j, Y",strtotime($final));
            $subject = "Peace Brookings: Reminder to update staff calendar!";
            //$body = "";
            $body = "Please click the link below to update your staff calendar for $first thru $last. \n";
            $body .="This calendar is due on $due \n\n";
            $body .= "https://www.peacebrookingscalendar.org/staff/login \n\n";
            $body .="$email";
            $host    = "peacebrookingscalendar.org";
            $port    =  "587";
            $user    = $servermail;
            $pass    = $serverpass;
            $headers = array("From"=> $from, "To"=>$to, "Subject"=>$subject);
            $smtp    = @Mail::factory("smtp", array("host"=>$host, "port"=>$port, "auth"=> true, "username"=>$user, "password"=>$pass));
            $mail    = @$smtp->send($to, $headers, $body);
    
            
        }
}

function sendEmail2($month)
{
    require_once('bdd.php');

    set_include_path("/home4/peacebr2/php");
    require_once "Mail.php";
    
    $servername = "localhost";
    $username = "peacebr2_user";
    $password = "dbuser";
    $dbname = "peacebr2_db";
    $conn = new mysqli($servername, $username, $password, $dbname);

    $sql = "SELECT ".$month." FROM calendar WHERE notification='first'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc(); 
    $first = $row[$month];
    $first = date("m-d-Y", strtotime($first));
    
    $sql = "SELECT ".$month." FROM calendar WHERE notification='last'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc(); 
    $last = $row[$month];
    $last = date("m-d-Y", strtotime($last));
    
    $sql = "SELECT ".$month." FROM calendar WHERE notification='due'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc(); 
    $due = $row[$month];
    $due = date("m-d-Y", strtotime($due));

    $sql = "SELECT email FROM email";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $email = $row["email"];

    //WHO THE EMAIL IS DELIVERED TO
   //$usersql = "SELECT testemail.email FROM testemail INNER JOIN userinfo ON userinfo.userID=testemail.userID INNER JOIN user ON userinfo.userID=user.userID WHERE userinfo.submitState = 0 AND user.archive = 0";
   $usersql = "SELECT userinfo.email FROM userinfo INNER JOIN user ON userinfo.userID=user.userID WHERE userinfo.submitState = 0 AND user.archive = 0";

        $query = $bdd->prepare( $usersql );
        $useremail = "";
        foreach($bdd->query($usersql) as $row)
        {
            $useremail = $row['email'];
            $servermail = "";
            $serverpass = "";
            $serversql = "select email,password from distro";
            $serveryQuery = $bdd->prepare($serversql);
            foreach($bdd->query($serversql) as $row)
            {
                $servermail = $row['email'];
                $serverpass = $row['password'];
            }
            
            $to     =   $useremail;
            $from   =   $servermail;
            $time = strtotime(date("Y-m-d"));
            $final = date("Y-m", strtotime("+1 month", $time));
            $forDate = date("F j, Y",strtotime($final));
            $subject = "Peace Brookings: Last reminder to update calendar!";
            //$body = "";
            $body = "Please click the link below to update calendar for $first thru $last. \n";
            $body .="This calendar is due on $due \n\n";
            $body .= "https://www.peacebrookingscalendar.org/ \n\n";
            $body .="$email";
            $host    = "peacebrookingscalendar.org";
            $port    =  "587";
            $user    = $servermail;
            $pass    = $serverpass;
            $headers = array("From"=> $from, "To"=>$to, "Subject"=>$subject);
            $smtp    = @Mail::factory("smtp", array("host"=>$host, "port"=>$port, "auth"=> true, "username"=>$user, "password"=>$pass));
            $mail    = @$smtp->send($to, $headers, $body);
    
            
        }
        
        //$usersql = "SELECT testemail.email FROM testemail INNER JOIN userinfo ON userinfo.userID=testemail.userID INNER JOIN user ON userinfo.userID=user.userID WHERE userinfo.submitState = 0 AND user.archive = 0";
    $usersql = "SELECT email FROM staff WHERE submitState = 0 AND archive = 0";

        $query = $bdd->prepare( $usersql );
        $useremail = "";
        foreach($bdd->query($usersql) as $row)
        {
            $useremail = $row['email'];
            $servermail = "";
            $serverpass = "";
            $serversql = "select email,password from distro";
            $serveryQuery = $bdd->prepare($serversql);
            foreach($bdd->query($serversql) as $row)
            {
                $servermail = $row['email'];
                $serverpass = $row['password'];
            }
            
            $to     =   $useremail;
            $from   =   $servermail;
            $time = strtotime(date("Y-m-d"));
            $final = date("Y-m", strtotime("+1 month", $time));
            $forDate = date("F j, Y",strtotime($final));
            $subject = "Peace Brookings: Last reminder to update staff calendar!";
            //$body = "";
            $body = "Please click the link below to update your staff calendar for $first thru $last. \n";
            $body .="This calendar is due on $due \n\n";
            $body .= "https://www.peacebrookingscalendar.org/staff/login \n\n";
            $body .="$email";
            $host    = "peacebrookingscalendar.org";
            $port    =  "587";
            $user    = $servermail;
            $pass    = $serverpass;
            $headers = array("From"=> $from, "To"=>$to, "Subject"=>$subject);
            $smtp    = @Mail::factory("smtp", array("host"=>$host, "port"=>$port, "auth"=> true, "username"=>$user, "password"=>$pass));
            $mail    = @$smtp->send($to, $headers, $body);
    
            
        }
}


                            
$servername = "localhost";
$username = "peacebr2_user";
$password = "dbuser";
$dbname = "peacebr2_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) 
{
    die("Connection failed: " . $conn->connect_error);
} 

date_default_timezone_set('America/Chicago');
$month = date('m',strtotime('+1 month'));

if((int)$month == 1)
{
    
    $today = date("Y-m-d");
    
    $sql = "SELECT jan FROM calendar WHERE notification = 'not1'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $day1 = $row["jan"];
   
    $sql2 = "SELECT jan FROM calendar WHERE notification = 'not2'";
    $result = $conn->query($sql2);
    $row = $result->fetch_assoc();
    $day2 = $row["jan"];
    
    $month = "jan";
    if($today == $day1)
    {
        sendEmail1($month);
    }
    else if($today == $day2)
    {
        sendEmail2($month);
    }
}
else if((int)$month == 2)
{
    
    $today = date("Y-m-d");
    
    $sql = "SELECT feb FROM calendar WHERE notification = 'not1'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $day1 = $row["feb"];
   
    $sql2 = "SELECT feb FROM calendar WHERE notification = 'not2'";
    $result = $conn->query($sql2);
    $row = $result->fetch_assoc();
    $day2 = $row["feb"];
    
    $month = "feb";
    if($today == $day1)
    if($today == $day1)
    {
        sendEmail1($month);
    }
    else if($today == $day2)
    {
        sendEmail2($month);
    }
}
else if((int)$month == 3)
{
    
    $today = date("Y-m-d");
    
    $sql = "SELECT mar FROM calendar WHERE notification = 'not1'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $day1 = $row["mar"];
   
    $sql2 = "SELECT mar FROM calendar WHERE notification = 'not2'";
    $result = $conn->query($sql2);
    $row = $result->fetch_assoc();
    $day2 = $row["mar"];
    
    $month = "mar";
    if($today == $day1)
    {
        sendEmail1($month);
    }
    else if($today == $day2)
    {
        sendEmail2($month);
    }
}
else if((int)$month == 4)
{
    
    $today = date("Y-m-d");
    
    $sql = "SELECT apr FROM calendar WHERE notification = 'not1'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $day1 = $row["apr"];
   
    $sql2 = "SELECT apr FROM calendar WHERE notification = 'not2'";
    $result = $conn->query($sql2);
    $row = $result->fetch_assoc();
    $day2 = $row["apr"];
    
    $month = "apr";
    if($today == $day1)
    {
        sendEmail1($month);
    }
    else if($today == $day2)
    {
        sendEmail2($month);
    }
}
else if((int)$month == 5)
{
    
    $today = date("Y-m-d");
    
    $sql = "SELECT may FROM calendar WHERE notification = 'not1'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $day1 = $row["may"];
   
    $sql2 = "SELECT may FROM calendar WHERE notification = 'not2'";
    $result = $conn->query($sql2);
    $row = $result->fetch_assoc();
    $day2 = $row["may"];
    
    $month = "may";
    if($today == $day1)
    {
        sendEmail1($month);
    }
    else if($today == $day2)
    {
        sendEmail2($month);
    }
}
else if((int)$month == 6)
{
    
    $today = date("Y-m-d");
    
    $sql = "SELECT jun FROM calendar WHERE notification = 'not1'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $day1 = $row["jun"];
   
    $sql2 = "SELECT jun FROM calendar WHERE notification = 'not2'";
    $result = $conn->query($sql2);
    $row = $result->fetch_assoc();
    $day2 = $row["jun"];
    
    $month = "jun";
    if($today == $day1)
    {
        sendEmail1($month);
    }
    else if($today == $day2)
    {
        sendEmail2($month);
    }
}
else if((int)$month == 7)
{
    
   $today = date("Y-m-d");
    
    $sql = "SELECT jul FROM calendar WHERE notification = 'not1'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $day1 = $row["jul"];
   
    $sql2 = "SELECT jul FROM calendar WHERE notification = 'not2'";
    $result = $conn->query($sql2);
    $row = $result->fetch_assoc();
    $day2 = $row["jul"];
    
    $month = "jul";
    if($today == $day1)
    {
        sendEmail1($month);
    }
    else if($today == $day2)
    {
        sendEmail2($month);
    }
}
else if((int)$month == 8)
{
    
   $today = date("Y-m-d");
    
    $sql = "SELECT aug FROM calendar WHERE notification = 'not1'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $day1 = $row["aug"];
   
    $sql2 = "SELECT aug FROM calendar WHERE notification = 'not2'";
    $result = $conn->query($sql2);
    $row = $result->fetch_assoc();
    $day2 = $row["aug"];
    
    $month = "aug";
    if($today == $day1)
    {
        sendEmail1($month);
    }
    else if($today == $day2)
    {
        sendEmail2($month);
    }
}
else if((int)$month == 9)
{
    
   $today = date("Y-m-d");
    
    $sql = "SELECT sep FROM calendar WHERE notification = 'not1'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $day1 = $row["sep"];
   
    $sql2 = "SELECT sep FROM calendar WHERE notification = 'not2'";
    $result = $conn->query($sql2);
    $row = $result->fetch_assoc();
    $day2 = $row["sep"];
    
    $month = "sep";
    if($today == $day1)
    {
        sendEmail1($month);
    }
    else if($today == $day2)
    {
        sendEmail2($month);
    }
}
else if((int)$month == 10)
{
    
    $today = date("Y-m-d");
    
    $sql = "SELECT oct FROM calendar WHERE notification = 'not1'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $day1 = $row["oct"];
   
    $sql2 = "SELECT oct FROM calendar WHERE notification = 'not2'";
    $result = $conn->query($sql2);
    $row = $result->fetch_assoc();
    $day2 = $row["oct"];
    
    $month = "oct";
    if($today == $day1)
    {
        sendEmail1($month);
    }
    else if($today == $day2)
    {
        sendEmail2($month);
    }
}
else if((int)$month == 11)
{
    
   $today = date("Y-m-d");
    
    $sql = "SELECT nov FROM calendar WHERE notification = 'not1'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $day1 = $row["nov"];
   
    $sql2 = "SELECT nov FROM calendar WHERE notification = 'not2'";
    $result = $conn->query($sql2);
    $row = $result->fetch_assoc();
    $day2 = $row["nov"];
    
    $month = "nov";
    if($today == $day1)
    {
        sendEmail1($month);
    }
    else if($today == $day2)
    {
        sendEmail2($month);
    }
}
else if((int)$month == 12)
{
    
   $today = date("Y-m-d");
    
    $sql = "SELECT dbr FROM calendar WHERE notification = 'not1'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $day1 = $row["dbr"];
   
    $sql2 = "SELECT dbr FROM calendar WHERE notification = 'not2'";
    $result = $conn->query($sql2);
    $row = $result->fetch_assoc();
    $day2 = $row["dbr"];
    
    $month = "dbr";
    if($today == $day1)
    {
        sendEmail1($month);
    }
    else if($today == $day2)
    {
        sendEmail2($month);
    }
}


?>