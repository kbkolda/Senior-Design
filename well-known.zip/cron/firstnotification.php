<?php
require_once('bdd.php');

set_include_path("/home4/peacebr2/php");
require_once "Mail.php";

//WHO THE EMAIL IS DELIVERED TO
$usersql = "SELECT email from userinfo";

    $query = $bdd->prepare( $usersql );
    $useremail = "";
    foreach($bdd->query($usersql) as $row)
    {
        $useremail = $row['email'];
        $servermail = "";
        $serverpass = "";
        $serversql = "select email,password from distro";
        $serveryQuery = $bdd->prepare($serversql);
        foreach($bdd->query($serversql) as $row)
        {
            $servermail = $row['email'];
            $serverpass = $row['password'];
        }
        
        $to     =   $useremail;
        $from   =   $servermail;
        $time = strtotime(date("Y-m-d"));
        $final = date("Y-m", strtotime("+1 month", $time));
        $forDate = date("F j, Y",strtotime($final));
        $subject = "Peace Brookings: First reminder to complete calendar schedule for $forDate!";
        $body ="";
        $host    = "peacebrookingscalendar.org";
        $port    =  "587";
        $user    = $servermail;
        $pass    = $serverpass;
        $headers = array("From"=> $from, "To"=>$to, "Subject"=>$subject);
        $smtp    = @Mail::factory("smtp", array("host"=>$host, "port"=>$port, "auth"=> true, "username"=>$user, "password"=>$pass));
        $mail    = @$smtp->send($to, $headers, $body);

        
    }
    
    
    $staffsql = "SELECT email from staff";
    $query = $bdd->prepare( $staffsql );
    $useremail = "";
    foreach($bdd->query($staffsql) as $row)
    {
        $useremail = $row['email'];
        $servermail = "";
        $serverpass = "";
        $serversql = "select email,password from distro";
        $serveryQuery = $bdd->prepare($serversql);
        foreach($bdd->query($serversql) as $row)
        {
            $servermail = $row['email'];
            $serverpass = $row['password'];
        }
        
        $to     =   $useremail;
        $from   =   $servermail;
        $time = strtotime(date("Y-m-d"));
        $final = date("Y-m", strtotime("+1 month", $time));
        $forDate = date("F j, Y",strtotime($final));
        $subject = "Peace Brookings Staff: First reminder to complete calendar schedule for $forDate!";
        $body ="www.peacebrookingscalendar.org/staff/login";
        $host    = "peacebrookingscalendar.org";
        $port    =  "587";
        $user    = $servermail;
        $pass    = $serverpass;
        $headers = array("From"=> $from, "To"=>$to, "Subject"=>$subject);
        $smtp    = @Mail::factory("smtp", array("host"=>$host, "port"=>$port, "auth"=> true, "username"=>$user, "password"=>$pass));
        $mail    = @$smtp->send($to, $headers, $body);

        
    }

    $sql = "UPDATE userinfo SET submitState= false WHERE 1";
    $bdd->prepare( $sql );
	$tquery = $bdd->prepare( $sql );
    $tquery->execute();  
	



?>