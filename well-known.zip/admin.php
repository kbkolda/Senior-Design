<?php

header("Location: admin/login_func/login");

?>