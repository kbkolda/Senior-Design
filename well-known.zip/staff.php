<?php

header("Location: staff/login_func/login");

?>